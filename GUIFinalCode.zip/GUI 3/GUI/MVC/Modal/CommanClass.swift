//
//  CommanClass.swift
//  GUI
//
//  Created by kamal on 05/01/18.
//  Copyright © 2018 Friends. All rights reserved.
//

import UIKit

class CommanClass: NSObject {

    
    
    func buttonInCircle (sender : UIButton)->UIButton {
        let buttonGet = sender
        buttonGet.layer.cornerRadius = 5
        return buttonGet
    }
    
    func ViewCircle (sender : UIView)->UIView {
        let view = sender
        view.layer.cornerRadius = view.frame.size.width / 2
        view.layer.masksToBounds = true
        view.layer.borderColor = UIColor.white.cgColor
        view.layer.borderWidth = 6
        return view
    }
    
}
