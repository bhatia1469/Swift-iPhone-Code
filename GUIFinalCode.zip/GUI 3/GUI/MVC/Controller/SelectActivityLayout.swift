//
//  SelectActivityLayout.swift
//  GUI
//
//  Created by kamal on 05/01/18.
//  Copyright © 2018 Friends. All rights reserved.
//

import UIKit

class SelectActivityLayout: BaseViewController,UICollectionViewDataSource {
    
    @IBOutlet var buttonPlus : UIButton!
    @IBOutlet var timeCollectionView: UICollectionView!
    
    
    let identifier = "timeCell"
    
    let optionsArray = ["File 1", "File 2", "File 3", "File 4", "File 5", "File 6", "File 7", "File 8", "File 9", "File 10", "File 11", "File 12","File 13","File 14", "File 15", "File 16", "File 17", "File 18", "File 19", "File 20", "File 21", "File 22", "File 23", "File 24"]
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = false
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         addSlideMenuButton()
        buttonPlus  = CommanClass().buttonInCircle(sender: buttonPlus)
    }
    
    // MARK :- UICollectionView DataSource Method
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return optionsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = timeCollectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! SelectCollectionViewCell
        cell.customeCellView.layer.borderWidth = 0.5
        cell.customeCellView.layer.borderColor = UIColor.lightGray.cgColor
        cell.customeCellView.layer.backgroundColor = UIColor.lightGray.cgColor
        cell.customeCellView.layer.cornerRadius = 10
        cell.customeLabel.text = self.optionsArray[indexPath.row]

        return cell
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
    
}

