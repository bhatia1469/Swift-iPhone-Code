//
//  SaveActivityLayout.swift
//  GUI
//
//  Created by kamal on 05/01/18.
//  Copyright © 2018 Friends. All rights reserved.
//

import UIKit

class SaveActivityLayout: BaseViewController,UICollectionViewDataSource {

    @IBOutlet var timeCollectionView: UICollectionView!
    
    @IBOutlet var imageView1: UIImageView!
    @IBOutlet var imageView2: UIImageView!
    @IBOutlet var imageView3: UIImageView!
    
    let identifier = "timeCell"
    
    let optionsArray = ["Files", "Twitter", "Facebook", "mail"]
    let iconsArray  = ["download","twitter-logo","facebook-logo (1)","close-envelope"]
    override func viewDidLoad() {
        super.viewDidLoad()

         addSlideMenuButton()
        imageView1.layer.borderColor = UIColor.white.cgColor
        imageView1.layer.borderWidth = 1.0
        
        imageView2.layer.borderColor = UIColor.white.cgColor
        imageView2.layer.borderWidth = 1.0
        
        imageView3.layer.borderColor = UIColor.white.cgColor
        imageView3.layer.borderWidth = 1.0
       
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return optionsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell = timeCollectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! SelectCollectionViewCell
        cell.customeCellView.layer.cornerRadius = 10
    
        cell.customeLabel.text = self.optionsArray[indexPath.row]
        cell.customImageView.image = UIImage(named:self.iconsArray[indexPath.row])!
        return cell
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
