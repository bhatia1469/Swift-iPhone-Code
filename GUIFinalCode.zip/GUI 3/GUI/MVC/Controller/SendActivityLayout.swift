//
//  SendActivityLayout.swift
//  GUI
//
//  Created by kamal on 05/01/18.
//  Copyright © 2018 Friends. All rights reserved.
//

import UIKit

class SendActivityLayout: BaseViewController , UICollectionViewDataSource {
    
    
    @IBOutlet var buttonPlus          : UIButton!
    @IBOutlet var timeCollectionView  : UICollectionView!
    @IBOutlet var imgView             : UIImageView!
    
    let identifier = "timeCell"
    
    let optionsArray = ["Files", "Twitter", "Facebook", "mail"]
    let iconsArray  = ["download","twitter-logo","facebook-logo (1)","close-envelope"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        
        imgView.layer.borderWidth = 2.0
        imgView.layer.borderColor = UIColor.white.cgColor
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = false
    }
    
    
    // MARK :- UICollectionView DataSource Method
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return optionsArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = timeCollectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! SelectCollectionViewCell
        cell.customeCellView.layer.borderWidth = 0.5
        cell.customeCellView.layer.borderColor = UIColor.lightGray.cgColor
        cell.customeCellView.layer.backgroundColor = UIColor.lightGray.cgColor
        cell.customeCellView.layer.cornerRadius = 10
        
        cell.customeLabel.text = self.optionsArray[indexPath.row]
        cell.customImageView.image = UIImage(named:self.iconsArray[indexPath.row])!
        return cell
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

