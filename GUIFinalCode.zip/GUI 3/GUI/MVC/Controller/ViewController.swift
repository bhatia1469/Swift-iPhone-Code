//
//  ViewController.swift
//  GUI
//
//  Created by kamal on 05/01/18.
//  Copyright © 2018 Friends. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var circleView : UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        circleView  = CommanClass().ViewCircle(sender: circleView)
    }

    
    // MARK :- UIButton Action Method
    
    @IBAction func actionButton() {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewControllerObject = storyboard.instantiateViewController(withIdentifier: "SelectActivityLayout") as! SelectActivityLayout
        self.navigationController?.pushViewController(viewControllerObject,animated: true)

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

