//
//  SelectCollectionViewCell.swift
//  GUI
//
//  Created by kamal on 06/01/18.
//  Copyright © 2018 Friends. All rights reserved.
//

import UIKit

class SelectCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var customeCellView : UIView!
    @IBOutlet var customeLabel : UILabel!
    @IBOutlet var customImageView : UIImageView!


}
